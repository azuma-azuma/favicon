const Controller = require('./controllers/modules/controller');

require('./controllers/domain-form')(Controller);
require('./controllers/domain-favicon')(Controller);
require('./controllers/ga')(Controller);
